class Produto:
    def __init__(self, produto, codigo, preço, quantidade):
        self.produto = produto
        self.codigo = codigo
        self.preço = preço
        self.quantidade = quantidade
