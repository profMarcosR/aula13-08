class Estoque:
    def __init__(self):
        self.lista_de_itens = []

    def adicionar(self, item):
        self.lista_de_itens.append(item)
        print(f"Produto '{item.produto}' adicionado com sucesso.")
    def remover(self,item):
        self.lista_de_itens.remove(item)
        print(f"Produto '{item.produto}' removido com sucesso.")
    def mostrar_inventario(self):
        print("\n--- Estoque ---")
        if len(self.lista_de_itens) < 1:
            print("Nenhum produto no estoque.")
        else:
            for item in self.lista_de_itens:
                print(f"Nome: {item.produto} |",
                      f"Código: {item.codigo} |",
                      f"Preço: R${item.preço}",
                      f" | Quantidade: {item.quantidade}")
        print("\n------------------")
    
    def calcular_total(self):
        total = 0
        for item in self.lista_de_itens:
            total = total + item.quantidade
        
        print(f"O estoque tem {total} produto(s)")
        
        if total == 0:
            print('O estoque está vazio')
        else:
            print('O estoque está cheio')
    
    
     
        
        
        
        