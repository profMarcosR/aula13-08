import Produto 
import Estoque


if __name__ == '__main__':
    Estoque_2025 = Estoque.Estoque()
    
    arroz = Produto.Produto("Arroz",66582, 19.99, 200)
    Estoque_2025.mostrar_inventario()
    feijão = Produto.Produto("Feijão",47521, 7.99, 206)
    açúcar = Produto.Produto("Açúcar",32658, 15.99, 188)
    
    Estoque_2025.adicionar(arroz)
    Estoque_2025.adicionar(feijão)
    Estoque_2025.adicionar(açúcar)
    Estoque_2025.mostrar_inventario()
    Estoque_2025.calcular_total()
    Estoque_2025.remover(arroz)
    Estoque_2025.remover(feijão)
    Estoque_2025.remover(açúcar)
    Estoque_2025.mostrar_inventario()
    Estoque_2025.calcular_total()