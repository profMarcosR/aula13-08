class Produto:
    def __init__(self, nome, id,preço,quantidade):
        self.nome = nome
        self.id = id
        self.preço = preço
        self.quantidade = quantidade

