class Estoque:
    def __init__(self):
        self.lista_de_produtos = []

    def adicionar(self, Produto):
        self.lista_de_produtos.append(Produto)
        print(f"Produto '{Produto.nome}' adicionado com sucesso.")

    def mostrar_Estoque(self):
        print("\n--- Estoque ---")
        if len(self.lista_de_produtos) < 1:
            print("Nenhum Produto no Estoque.")
        else:
            for Produto in self.lista_de_produtos:
                print(f"Nome: {Produto.nome} |",
                      f"ID: {Produto.id}",
                      f" | quantidade: {Produto.quantidade}",
                      f" | Preço:{Produto.preço}")

    def remover(self,Produto):
      self.lista_de_produtos.remove(Produto)
      print(f"Produto '{Produto.nome}' removido com sucesso.")
     
      
    def atualizar_qtd(self,entrada,nova_qtd):
        for P in self.lista_de_produtos:
            if entrada == P.id:
                P.quantidade = nova_qtd
                print(f'quantidade do produto:{P.nome} atualizada para {nova_qtd}')
                
                
    def produtos_faltantes(self):
        for pdt in self.lista_de_produtos:
            if pdt.quantidade == 0:
                print(f'{pdt.nome} está em falta')
                
    def total_de_produtos(self):
        t_produtos = 0
        for P in self.lista_de_produtos:
            t_produtos += P.quantidade
        print(f'quantidade total de produtos em estoque:{t_produtos}')
                
      
          

    print("\n------------------")