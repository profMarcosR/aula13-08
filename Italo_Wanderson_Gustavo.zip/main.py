import PRT
import Est




if __name__ == '__main__':
    mesa = PRT.Produto('mesa',123,400,30)
    monitor = PRT.Produto('monitor',321,700,90)
    cpu = PRT.Produto('cpu',231,30,110 )
    
    Estoque_2025 = Est.Estoque()
    
    Estoque_2025.adicionar(mesa)
    Estoque_2025.adicionar(monitor)
    Estoque_2025.adicionar(cpu)
    
    Estoque_2025.total_de_produtos()
    
    
    

