class Pizza:
    def __init__(self, nome, tamanho, valor, gluten=True, vegana=False):
        self.nome = nome
        self.tamanho = tamanho
        self.valor = valor
        self.gluten = gluten
        self.vegana = vegana
        