
class Cliente():
    def __init__(self, nome, contato, endereco):
        self.nome = nome
        self.contato = contato
        self.endereco = endereco

    
