class ContaBancaria:
    def __init__(self, titular, saldo_inicial):
        self.titular = titular
        self.saldo_inicial = saldo_inicial
        self.movimentacao = []
        
    def depositar(self, deposito): 
        self.deposito = deposito
        self.saldo_inicial += self.deposito
        self.movimentacao.append(deposito)

    def sacar(self, saque):
        self.saque = saque
        self.saldo_inicial -= self.saque
        self.movimentacao.append(-saque)

    def extrato(self):
        for i in self.movimentacao:
            if i > 0:
                print(f"Credito         +{i}")
            else:
                print(f"Debito          {i}")
                
        print(f"Titular: {self.titular}  |  Saldo Atual: R$ {self.saldo_inicial}")


