import conta

if __name__ == '__main__':
    marcos_conta = conta.ContaBancaria("Marcos", 1000)
    
    marcos_conta.extrato()
    marcos_conta.depositar(500)
    marcos_conta.sacar(200)
    marcos_conta.extrato()
    
    joao_conta = conta.ContaBancaria("João", 5000)
    
    joao_conta.extrato()
    joao_conta.depositar(999)
    joao_conta.sacar(150)
    joao_conta.extrato()
