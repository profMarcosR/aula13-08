import it
import inv


if __name__ == '__main__':
    inventario_2025 = inv.Inventario()
    
    
    mesa = it.Item("mesa", 123, "usado", "lab211")
    monitor = it.Item("monitor", 321, "usado", "lab211")
    cpu = it.Item("cpu", 231, "usado", "lab211")
    
    inventario_2025.adicionar(mesa)
    inventario_2025.adicionar(monitor)
    inventario_2025.adicionar(cpu)
    
    inventario_2025.remover(mesa)
    inventario_2025.mostrar_inventario()
    
    