class Item:
    def __init__(self, nome, id, estado, local):
        self.nome = nome
        self.id = id
        self.estado = estado
        self.local = local