class Inventario:
    def __init__(self):
        self.lista_de_itens = []

    def adicionar(self, item):
        self.lista_de_itens.append(item)
        print(f"Item '{item.nome}' adicionado com sucesso.")
    
    def remover(self, item):
        self.lista_de_itens.remove(item)
        print(f"Item '{item.nome}' foi removido com sucesso.")
        
    def mostrar_inventario(self):
        print("\n--- Inventário ---")
        if len(self.lista_de_itens) < 1:
            print("Nenhum item no inventário.")
        else:
            for item in self.lista_de_itens:
                print(f"Nome: {item.nome} |",
                      f"ID: {item.id}",
                      f" | Estado: {item.estado}")
        print("\n------------------")